/**
 * @description get users
 * @route GET /api/v1/users
 * @access Private
 *
 */

export const getUsers = (req, res, next) => {};
